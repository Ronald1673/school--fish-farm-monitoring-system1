
<?php
// Initialize the error array
$errors = array();

if (isset($_POST['submit'])) {
    // Include the config.php file
    include 'config.php';

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = md5($_POST['password']);
    $cpass = md5($_POST['cpassword']);
    $user_type = $_POST['user_type'];
    $gender = $_POST['gender']; // Get the selected gender value

    // Validate the inputs
    if (empty($name)) {
        $errors[] = 'Name is required';
    }
    if (empty($email)) {
        $errors[] = 'Email is required';
    }
    if (empty($gender)) {
        $errors[] = 'Gender is required';
    }

    if (empty($errors)) {
      $select = "SELECT * FROM Members WHERE email = '$email'";
      $result = mysqli_query($conn, $select);
  
      if (mysqli_num_rows($result) > 0) {
          $errors[] = 'User already exists!';
      } else {
          if ($pass != $cpass) {
              $errors[] = 'Passwords do not match!';
          } else {
              $insert = "INSERT INTO Members (name, email, password, user_type, gender) VALUES ('$name','$email','$pass','$user_type','$gender')";
              if (mysqli_query($conn, $insert)) {
                  echo "<script type='text/javascript'>alert('You have been registered'); window.location = 'login.php';</script>";
                  exit();
              } else {
                  $errors[] = 'Error: ' . mysqli_error($conn);
              }
          }
      }
  }
}
?>  
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="x-icon" href="image/icon.png">
    <title>Registration</title>
    <link rel="stylesheet" href="css/style22.css">
    <link rel="stylesheet" href="css/font/css/all.css">
    <link rel="stylesheet" href="css/loader.css">
    <style>
        .logo {
            display: flex;
            /* Added margin-bottom */
        }

        img {
            max-width: 10%;
            height:10%;
            border-radius: 50%;
        }

         h2 {
         /* Adjusted margin-top */
            color: whitesmoke;
            font-family: 'Courier New', Courier, monospace;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <div class="loader"></div>

    <div class="contain">
       <div class="logo">
            <img src="image/Icon.png" alt="Logo">
            <h2>Lumbira Fish Farm</h2>
            </div>
        <div class="wrapper">
            <div class="title"><span>Registration Form</span></div>
            <form action="#" method="post">
            <?php
            if (!empty($errors)) { // Corrected variable name
                foreach ($errors as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                }
            }
            ?>

            <div class="row">
                <i class="fas fa-user"></i>
                <input type="text" name="name" placeholder="Name" required>
            </div>
            <div class="row">
                <i class="fas fa-envelope"></i>
                <input type="text" name="email" placeholder="Email" required>
            </div>

            <div class="row">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <div class="row">
                <i class="fas fa-lock"></i>
                <input type="password" name="cpassword" placeholder="Confirm Password" required>
            </div>

            <div class="row">
                <select name="user_type">
                    <option value="Member">Member</option>
					
                </select>
            </div>

            <div class="type">
                <input type="radio" id="option1" name="gender" value="Male">
                <label for="option1">Male</label><br>
                <input type="radio" id="option2" name="gender" value="Female">
                <label for="option2">Female</label><br>
            </div>

            <br>
            <div class="row button">
                <input type="submit" name="submit"value="Register">
            </div>
            <div class="signup-link">Already a member? <a href="login.php">Login</a></div>
            <div class="signup-link"><a href="index.html">Cancel</a></div>
        </form>
            
        </div>
    </div>
</body>
<script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
</html>

