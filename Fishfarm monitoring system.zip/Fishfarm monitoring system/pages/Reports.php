<?php

if (isset($_POST['submit'])){
  include 'config.php';


  $Membername=mysqli_real_escape_string($conn,$_POST['Membername']);
  $Membersid=$_POST['Membersid'];
  $date=$_POST['date'];
  $description=$_POST['description'];
  $PriceOfFish=$_POST['PriceOfFish'];
  $fishSold=$_POST['fishSold'];
  $FishLeft=$_POST['FishLeft'];
  $totalIncome=$_POST['totalIncome'];
  $lossMade=$_POST['lossMade'];

  $sql="INSERT INTO Salesreport(Membername,Membersid,date,description,PriceOfFish,fishSold,FishLeft,totalIncome,lossMade)
  VALUES('$Membername','$Membersid','$date','$description','$PriceOfFish','$fishSold','$FishLeft','$totalIncome','$lossMade')";
   mysqli_query($conn,$sql);

}

?>
<?php
if(isset($_POST['submit'])) {
  echo "<script type='text/javascript'>alert('Report Sent');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <link rel="shortcut icon" type="x-icon" href="../image/Icon.png">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Reports</title>
  
  <link rel="stylesheet" href="../css/Contents.css">
  <link rel="stylesheet" href="../css/loader.css">
</head>
<body>
<div class="loader"></div>
  <div class="side">
    <div class="logo">
      <img src="../image/Icon.png" alt="Logo">
      <h2 id="h2">Lumbira Fish Farm</h2>
    </div>
   
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="Reports.php"class="active">Reports</a></li>
      <li><a href="profile.php" >Profile</a></li>
      <li><a href="../login.php">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="header">
      <h1>Sales Report</h1>
    </div>

    <div class="dashboard">
      <h2>Fish Sales Form</h2>
    
      <form id="fishSalesForm" action="#" method="post">
          <label for="name">Members Name:</label>
          <input type="text" id="name" name="Membername" required>

          <label for="Membersid" >Members ID:</label>
          <input type="text" id="Membersid" name="Membersid" placeholder="Get id from profile" >
          
          <label for="date">Date of Submission:</label>
          <input type="date" id="date" name="date" required>
  
          <label for="description">Description:</label>
          <textarea id="description" name="description" rows="4" required></textarea>
  
          <label for="amountOfFish">Price per Fish:</label>
          <input type="number" id="amountOfFish" name="PriceOfFish" required>
  
          <label for="fishSold">Fish Sold:</label>
          <input type="number" id="fishSold" name="fishSold" required>
  
          <label for="amountOfFishLeft">Number of Fish Left:</label>
          <input type="number" id="amountOfFishLeft" name="FishLeft" required>
  
          <label for="totalIncome">Total Income:</label>
          <input type="number" id="totalIncome" name="totalIncome" readonly>
  
          <label for="lossMade">Loss Made:</label>
          <input type="number" id="lossMade" name="lossMade" readonly>
  
          <button type="button" onclick="calculateResults()">Calculate Results</button>
          <button type="submit" name="submit">Submit</button>
      </form>
  
      
    </div>

    
  </div>
<script>
          function calculateResults() {
              const amountOfFish = parseFloat(document.getElementById('amountOfFish').value);
              const fishSold = parseFloat(document.getElementById('fishSold').value);
              const amountOfFishLeft = parseFloat(document.getElementById('amountOfFishLeft').value);
  
              const totalIncome = amountOfFish * fishSold;
              const lossMade = amountOfFishLeft * amountOfFish; 
  
              document.getElementById('totalIncome').value = totalIncome.toFixed(2);
              document.getElementById('lossMade').value = lossMade.toFixed(2);
          }
      </script>
      <script>
  window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>

</body>
</html>
