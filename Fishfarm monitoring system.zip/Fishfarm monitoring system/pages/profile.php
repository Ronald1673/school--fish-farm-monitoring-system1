<?php
// Start the session (make sure this is at the top of your PHP file)
session_start();

// Include the database configuration file
include 'config.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <link rel="shortcut icon" type="x-icon" href="../image/Icon.png">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Profile</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/Contents.css">
  <link rel="stylesheet" href="../css/form.css">
   <link rel="stylesheet" href="../css/Ronald.css">
</head>
<body>

  <div class="side">
    <div class="logo">
      <img src="../image/Icon.png" alt="Logo">
      <h2 id="h2">Lumbira Fish Farm</h2>
    </div>
   
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="Reports.php">Reports</a></li>
      <li><a href="profile.php" class="active">Profile</a></li>
      <li><a href="../login.php">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="header">
      <h1>Welcome</h1>
    </div>

    <div class="dashboard">
      
      <div class="box2">
      <form method="post">
      <!-- Display the Membersid in the input field -->
      <label for="Membersid">Members ID:</label>
      <input type="text" id="Membersid" name="Membersid" required readonly>
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        <input type="submit" value="Submit">
      </form>
        </div>
        
     
  
    
      </div>
</div>
    <div class="footer">
      <p>Lumbira Fish Farm&copy; 2023</p>
    </div>
  </div>

  <?php
  // Include the database connection file
  include 'config.php';

  // Check if the form is submitted
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      // Get the email from the input box
      $email = $_POST["email"];

      // SQL query to get Membersid based on email
      $sql = "SELECT Membersid FROM Members WHERE Email = '$email'";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
          // Fetch the result
          $row = $result->fetch_assoc();
          $membersid = $row["Membersid"];

          // Set the value of Membersid in the input field
          echo '<script>document.getElementById("Membersid").value = "' . $membersid . '";</script>';
      } else {
          echo "No matching record found.";
      }
  }

  // Close the connection
  $conn->close();
  ?>

</body>
</html>
