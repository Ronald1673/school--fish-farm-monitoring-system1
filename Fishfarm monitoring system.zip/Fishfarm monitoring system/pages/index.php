<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <link rel="shortcut icon" type="x-icon" href="../image/Icon.png">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Members Dashboard</title>
   <link rel="stylesheet" href="../css/Contents.css">
   <link rel="stylesheet" href="../css/font/css/all.css">
</head>
<body>

  <div class="side">
    <div class="logo">
      <img src="../image/Icon.png" alt="Logo">
      <h2 id="h2">Lumbira Fish Farm</h2>
    </div>
   
    <ul>
      <li><a href="index.php" class="active">Home</a></li>
      <li><a href="Reports.php">Reports</a></li>
      <li><a href="profile.php">Profile</a></li>
      <li><a href="../login.php">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="header">
      <h1>Welcome</h1>
      <div class="bell"><i class="fa-regular fa-bell fa-2x"></i></div>
    </div>
    <br>
    <div class="dashboard1">
      <div class="box1">
        <h6>Last Report submitted</h6>
        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Lumbira_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming $salesId is the provided salesid, replace it with the actual variable or value
$Salesid = 1; // Example value, replace it with your actual variable or value

// Prepare and execute the SQL query
$sql = "SELECT date FROM Salesreport WHERE Salesid = ? OR Salesid >= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $Salesid, $Salesid);
$stmt->execute();
$stmt->bind_result($date);
$stmt->fetch();
$stmt->close();

// Display the date in the specified div
echo '<div class="data2">' . $date . '</div>';

// Close the database connection
$conn->close();
?>

      </div>

      <div class="box2">
        <h6>Fish Harvest Day</h6>
        <div class="data1">
          <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $dbname = "lumbira_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query
    $sql = "SELECT Age FROM typesoffish";

    // Execute query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            $current_age = $row["Age"];
            $maturity_age = 10; // Maturity age in weeks
            $remaining_weeks = $maturity_age - $current_age;

            // Calculate the date when the remaining weeks will be reached
            $current_date = date_create();
            $future_date = date_add($current_date, date_interval_create_from_date_string($remaining_weeks . " weeks"));
            $maturity_date = date_format($future_date, 'Y-m-d');

            // Output maturity date within the data1 div
            echo "<p class='pp'>$maturity_date</p>";
        }
    } else {
        echo "0 results";
    }

    // Close connection
    $conn->close();
?>

        </div>
      </div>
      <div class="box3">
        <h6>Tank</h6>
        <div class="data1">
		<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "Lumbira_db"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve tank names
$sql = "SELECT Tankname FROM typesoffish";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "" . $row["Tankname"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>

		</div>
      </div>
      <div class="box4">
        <h6>Members Group</h6>
        <div class="data2">Group 1</div>
      </div>
    </div>

    <div class="footer">
      <p>Lumbira Fish Farm&copy; 2023</p>
    </div>
  </div>

</body>
</html>
