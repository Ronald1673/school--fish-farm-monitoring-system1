<?php
@include 'config.php';

?>
<?php
require_once "config.php";
$alerts = $conn->query("SELECT COUNT(Salesid) as total FROM Salesreport WHERE Salesid = 1 OR Salesid > 1");
$notification = $alerts->fetch_array();
?> 
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <link rel="shortcut icon" type="x-icon" href="../image/icon.png">
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Members</title>
      <link rel="stylesheet" href="../css/cs.css">
      <link rel="stylesheet" href="../css/styel.css">
	  <link rel="stylesheet" href="../css/loader.css">
      <link rel="stylesheet" href="../css/font/css/all.css">
     
  </head>
  <body>
  <div class="loader"></div>
      <div class="bar">
      
          <form id="search">
              <input  id="search" type="text">
              <input id="se" type="submit"
               value="Search">
              </form>
              <style>
                  input[type="submit"]{
                      opacity: 0;
                      transition: 1.3s;
                  }
                  input:not(:placeholder-shown)+
                  input[type="submit"]{
                      opacity:9;
                  }
              
              </style>
      </div>
      
  
      <div class="sidebar">
          <div class="sidebar-brand">
              <h2><span ></span>Welcome ADMIN</h2>
          </div>
          <br>
          <div class="im">
              <img class="im"src="../image/icon.png" alt="">
            </div>
      <br>
      <br>
          <div class="sidebar-menu">
              <ul>
                  <li>
                      <a href="index.php" ><span class="fas fa-home fa-2x"></span><span>Home</span></a>
                  </li>
                  <li>
                      <a href="Notification.php" ><span class="fas fa-bell   fa-2x"></span><span>Notification</span><em><?php echo $notification['total'] ?></em></a>
                  </li>
                  <li>
                      <a href="Groups.php" class="active"><span class="fa fa-users"></span><span>Groups</span></a>
                  </li>
                  <li>
                      <a href="Reports.php"><span class="fa fa-line-chart"></span><span>Reports</span></a>
                  </li>
                  <li>
                  <a href="index2.php"><img src="../image/tank.png_32.png" alt=""><span>Tank Records</span></a>
                  </li>
                  <li>
                      <a href="task.php"><span><img src="../image/task.png_32.png" alt=""></span><span>Records</span></a>
                  </li>
      
                  <li>
                      <a href="logout.php"><span class="fa-solid fa-right-from-bracket"></span><span>Logout</span></a>
                  </li>
              </ul>
          </div>
      </div>
      <br>
  
      <h6>Fish Farm members </h6>
  
      <div class="flex">
         
          
      </div>
      <div class="ba"></div>
  </body>
  <script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
  </html>
  
  
  