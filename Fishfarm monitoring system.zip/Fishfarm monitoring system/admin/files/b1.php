<!DOCTYPE html>
<html>
<head>
    <title>Bar Chart</title>
          <script src="chart.umd.js"></script>
</head>
<body>
 <canvas id="fishTankChart" width="fit-content" height="220"></canvas>

 
<script>
    // Sample fish tank data
    var fishTankData = {
        labels: [], // Labels for timestamps
        datasets: [{
            label: 'Water Level (%)',
            backgroundColor: '#2E3239',
            borderColor: 'rgba(0, 0, 0, 0.2)',
            yAxisID: 'y-axis-1', // Assigning y-axis for water level
            data: [] // Water level data
        },
        {
            label: 'Temperature (°C)',
            backgroundColor: '#77b0f5',
            borderColor: 'rgba(0, 0, 0, 0.2)',
            yAxisID: 'y-axis-2', // Assigning y-axis for temperature
            data: [] // Temperature data
        }]
    };

    // Chart configuration
    var chartConfig = {
        type: 'bar',
        data: fishTankData,
        options: {
            scales: {
                yAxes: [
                    {
                        id: 'y-axis-1',
                        type: 'linear',
                        position: 'left',
                        ticks: {
                            callback: function(value, index, values) {
                                return value + '%'; // Adding '%' sign to water level labels
                            }
                        }
                    },
                    {
                        id: 'y-axis-2',
                        type: 'linear',
                        position: 'right',
                        ticks: {
                            callback: function(value, index, values) {
                                return value + '°C'; // Adding '°C' sign to temperature labels
                            }
                        }
                    }
                ]
            },
            plugins: {
                annotation: {
                    annotations: [{
                        type: 'line',
                        mode: 'horizontal',
                        scaleID: 'y-axis-1',
                        value: 65,
                        borderColor: 'green',
                        borderWidth: 2,
                        label: {
                            enabled: true,
                            content: 'Normal Water Level'
                        }
                    },
                    {
                        type: 'line',
                        mode: 'horizontal',
                        scaleID: 'y-axis-2',
                        value: 25,
                        borderColor: 'green',
                        borderWidth: 2,
                        label: {
                            enabled: true,
                            content: 'Normal Temperature'
                        }
                    }]
                }
            },
            layout: {
                padding: {
                    left: 10,
                    right: 10,
                    top: 10,
                    bottom: 10
                },
                backgroundColor: 'black' // Set background color of the chart index
            }
        }
    };

    // Get the canvas element
    var ctx = document.getElementById('fishTankChart').getContext('2d');

    // Create the bar graph
    var myChart = new Chart(ctx, chartConfig);

    // Function to add new data points
    function addData(timeStamp, waterLevel, temperature) {
        myChart.data.labels.push(timeStamp);
        myChart.data.datasets[0].data.push(waterLevel);
        myChart.data.datasets[1].data.push(temperature);
        myChart.update();
    }

    // PHP code to fetch data from the database
    <?php
        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "lumbira_db";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to fetch data
        $sql = "SELECT Time, Waterlevel, Temperature FROM fishtank";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "addData('".$row["Time"]."', ".$row["Waterlevel"].", ".$row["Temperature"].");\n";
            }
        } else {
            echo "0 results";
        }
        $conn->close();
    ?>
</script>
</body>
</html>