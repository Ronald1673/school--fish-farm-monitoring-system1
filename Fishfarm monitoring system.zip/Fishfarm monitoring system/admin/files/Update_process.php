<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lumbira_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fishid = $_POST['Fishid'];
    $tankname = $_POST['Tankname'];
    $fishname = $_POST['Fishname'];
	$Color = $_POST['Color'];
	$Origin = $_POST['Origin'];
	$Age = $_POST['Age'];
	$Feedtype = $_POST['Feedtype'];
	$NumberOfFish = $_POST['NumberOfFish'];
    // Retrieve other form fields as needed
    
    // Prepare update query
    $sql = "UPDATE typesoffish SET Tankname='$tankname', Fishname='$fishname',Color='$Color',Origin='$Origin',Age='$Age',Feedtype='$Feedtype',NumberOfFish='$NumberOfFish' WHERE Fishid=$fishid";
    // Add other fields to update in the query as needed
    
    if ($conn->query($sql) === TRUE) {
        // Redirect back to index.php after successful update
        header("Location: index2.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>
