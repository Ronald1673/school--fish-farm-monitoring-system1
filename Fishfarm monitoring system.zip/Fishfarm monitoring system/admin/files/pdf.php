<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate PDF</title>
    <style>
        #generatePdfBtn {
            background-color: #2E3239; /* Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: block; /* Changed to block to center */
            font-size: 16px;
            margin: auto; /* To center */
            cursor: pointer;
            border-radius: 10px;
            transition-duration: 0.4s;
            height:62px;
        }

        #generatePdfBtn:hover {
            background-color: #4CAF58; /* Dark Grey */
            color: white;
        }

        #generatePdfBtn:active {
            background-color: #2E3239; /* Green */
            color: white;
        }
    </style>
</head>
<body>
    <button id="generatePdfBtn">Download  <br> <img src="../image/pdf.ico"></button> <!-- Added closing tag for image src -->

    <script>
        document.getElementById('generatePdfBtn').addEventListener('click', function() {
            window.location.href = 'New/gen.php';
        });
    </script>
</body>
</html>

