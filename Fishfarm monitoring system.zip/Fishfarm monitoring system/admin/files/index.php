<?php
require_once "config.php";

$alerts = $conn->query("SELECT COUNT(Salesid) as total FROM Salesreport WHERE Salesid = 1 OR Salesid > 1");
$notification = $alerts->fetch_array();

// Function to insert data into the database
function insertData($waterLevel, $waterTemperature) {
    global $conn; // Access the global database connection object

    // Prepare SQL statement
    $sql = "INSERT INTO fishtank (Time, Date, waterlevel, Temperature) VALUES (CURRENT_TIME(), CURRENT_DATE(), '$waterLevel', '$waterTemperature')";

    // Execute the SQL query
    if ($conn->query($sql) === TRUE) {
        echo ".";
    } else {
        echo "Error: " . $sql . "" . $conn->error;
    }
}

// Fetch temperature data from Arduino
$temperatureData = @file_get_contents('http://192.168.137.4/getTemperature');

if ($temperatureData === FALSE) {
    // Handle error case for temperature
    echo "";
} else {
    // Decode JSON data for temperature
    $temperatureArray = json_decode($temperatureData, true);

    if (isset($temperatureArray['temperature'])) {
        // Extract temperature value
        $waterTemperature = $temperatureArray['temperature'];
        
        // Fetch water level data from ESP8266
        $waterLevelData = @file_get_contents('http://192.168.137.4/getWaterLevel');

        if ($waterLevelData === FALSE) {
            // Handle error case for water level
            echo "";
        } else {
            // Decode JSON data for water level
            $waterLevelArray = json_decode($waterLevelData, true);

            if (isset($waterLevelArray['waterLevelPercentage'])) {
                // Extract water level value
                $waterLevel = $waterLevelArray['waterLevelPercentage'];
                
                // Call the insertData function to insert data into the database
                insertData($waterLevel, $waterTemperature);
            } 
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="../image/icon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="60"> <!-- Refresh every 1 minute -->
    <title>Home</title>
    <link rel="stylesheet" href="../css/cs.css">
    <link rel="stylesheet" href="../css/styel.css">
    <link rel="stylesheet" href="../css/font/css/all.css">
    <link rel="stylesheet" href="../css/Contents.css">
    <link rel="stylesheet" href="../css/loader.css">
    <link rel="stylesheet" href="../css/blink.css">
    <style>
    
    </style>
</head>
<body>

<div class="bar">
<div class="bell"><i class="fa-regular fa-bell fa-2x"><?php echo $notification['total'] ?></i></div>
</div>
<div class="loader"></div>
<div class="sidebar">
    <div class="sidebar-brand">
        <h2><span></span>Welcome ADMIN</h2>
    </div>
    <br>
    <div class="im">
        <img class="im" src="../image/icon.png" alt="">
    </div>
    <br>
    <br>
    <div class="sidebar-menu">
        <ul>
            <li>
                <a href="index.php" class="active"><span class="fas fa-home fa-2x"></span><span>Home</span></a>
            </li>
            <li>
                <a href="Notification.php"><span class="fas fa-bell fa-2x"></span><span>Notification</span> <em><?php echo $notification['total'] ?></em></a>
            </li>
            <li>
                <a href="Groups.php"><span class="fa fa-users"></span><span>Groups</span></a>
            </li>
            <li>
                <a href="Reports.php"><img src="../image/report.png_32.png" alt=""><span>Reports</span></a>
            </li>
            <li>
                  <a href="index2.php"><img src="../image/tank.png_32.png" alt=""><span>Tank Records</span></a>
                  </li>
            <li>
                <a href="task.php"><span><img src="../image/task.png_32.png" alt=""></span><span>Records</span></a>
            </li>

            <li>
                <a href="logout.php"><span class="fa-solid fa-right-from-bracket"></span><span>Logout</span></a>
            </li>
        </ul>
    </div>
</div>
<br>

<div class="flex">
<?php
require_once "config.php";
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to count the number of rows in the table
$sql = "SELECT COUNT(*) as total FROM members";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $totalMembers = $row["total"];

        // Calculate the number of groups with 4 members each
        $numGroups = ceil($totalMembers / 4);
        
        // Store the value of $numGroups in a variable for later use
        $numGroupsText = $numGroups . " groups";
    }
} else {
    $numGroupsText = "0 groups";
}

// Close the database connection
$conn->close();
?>



    <div class="item1">
        <p>Groups<span class="fa fa-users fa-2x" style="color:#7c939683;"></span></p>
        <label for="myInputGroup"></label>
        <input class="myInput" type="text" id="myInputGroup" name="groups" value="<?php echo $numGroups?>" readonly>
        
    </div>
    <br>

    <div class="item2">
        <p>Members<span><img src="../image/member.svg_32.png" alt=""></span></p>
        <label for="myInputMembers"></label>
        <input class="myInput" type="text" id="myInputMembers" name="members" value="<?php echo $totalMembers?>" readonly>
    </div>
    <br>

    <div class="item3">
        <p>Water Level <span><img src="../image/water.png_32.png" alt=""></span></p>
        <?php
        // Fetch water level data from ESP8266
        $waterLevelData = @file_get_contents('http://192.168.137.4/getWaterLevel');

        if ($waterLevelData === FALSE) {
            // Handle error case for water level
            echo "<p>Error fetching water level.</p>";
        } else {
            // Decode JSON data for water level
            $waterLevelArray = json_decode($waterLevelData, true);

            if (isset($waterLevelArray['waterLevelPercentage'])) {
                // Extract water level value
                $waterLevel = $waterLevelArray['waterLevelPercentage'];
                echo '<input class="myInput" type="text" id="myInputWaterLevel" name="waterlevel" value="' . $waterLevel . '%" readonly>';
            } else {
                // Handle case where water level is not available
                echo "<p>No water level data available.</p>";
            }
        }
        ?>
    </div>
    <br>

    <div class="item4">
        <p>Temperature <span><img src="../image/temperature_.svg_32.png" alt=""></span></p>
          
          <?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/vendor/PHPMailer/src/Exception.php';
require 'php/vendor/PHPMailer/src/PHPMailer.php';
require 'php/vendor/PHPMailer/src/SMTP.php';

session_start();

// Function to send email
function sendEmail($subject, $message, $email, $temperature)
{
    $mail = new PHPMailer(true);                            
    try {
        // Server settings
        $mail->isSMTP();                                     
        $mail->Host = 'smtp.gmail.com';                      
        $mail->SMTPAuth = true;                             
        $mail->Username = 'lumbirafishfarm@gmail.com';     
        $mail->Password = 'sapv kkck umfn zgyr';             
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );                         
        $mail->SMTPSecure = 'ssl';                           
        $mail->Port = 465;                                   

        // Send Email
        $mail->setFrom('lumbirafishfarm@gmail.com' );
        
        // Recipients
        $mail->addAddress($email);              
        $mail->addReplyTo('lumbirafishfarm@gmail.com');
        
        // Content
        $mail->isHTML(true);                                  
        $mail->Subject = $subject;
        $mail->Body    = $message . "<br><br>Actual temperature: " . $temperature . "°C";

        $mail->send();
        $_SESSION['result'] = 'Message has been sent';
        $_SESSION['status'] = 'ok';
    } catch (Exception $e) {
        $_SESSION['result'] = 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo;
        $_SESSION['status'] = 'error';
    }
}

// Function to fetch recipient email addresses from the database
function getRecipientEmails()
{
    // Establish database connection
    $servername = "localhost"; // Change this if your database server is different
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "lumbira_db"; // Change this to your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to fetch email addresses from admin table
    $sql = "SELECT email FROM admin";
    $result = $conn->query($sql);

    $emails = array();

    if ($result->num_rows > 0) {
        // Fetch email addresses
        while ($row = $result->fetch_assoc()) {
            $emails[] = $row["email"];
        }
    }

    $conn->close();

    return $emails;
}

// Fetch temperature data from Arduino
$temperatureData = @file_get_contents('http://192.168.137.4/getTemperature');

if ($temperatureData === FALSE) {
    // Handle error case for temperature
    echo "<p>Error fetching temperature.</p>";
} else {
    // Decode JSON data for temperature
    $temperatureArray = json_decode($temperatureData, true);

    if (isset($temperatureArray['temperature'])) {
        // Extract temperature value
        $waterTemperature = $temperatureArray['temperature'];
       
        echo '<input class="myInput" type="text" id="watertemperature" name="waterTemperature" value="' . $waterTemperature . ' &deg;C" readonly>';
        
        // Get recipient email addresses from the database
        $recipientEmails = getRecipientEmails();
        
        if (!empty($recipientEmails)) {
            foreach ($recipientEmails as $recipientEmail) {
                // Check temperature range and set circle class accordingly
                if ($waterTemperature < 20.0) {
                    echo '<div id="blink-circle" class="blink-blue"></div>';
                    // Send email notification for low temperature
                    sendEmail("Low Temperature Warning", "The water temperature is below 20 degrees Celsius.", $recipientEmail, $waterTemperature);
                } elseif ($waterTemperature > 30.0) {
                    echo '<div id="blink-circle" class="blink-red"></div>';
                    // Send email notification for high temperature
                    sendEmail("High Temperature Warning", "The water temperature is above 30 degrees Celsius.", $recipientEmail, $waterTemperature);
                } else {
                    echo '<div id="blink-circle" class="green"></div>';
                }
            }
        } else {
            echo "<p>No recipient email addresses found.</p>";
        }
    } else {
        // Handle case where temperature is not available
        echo "<p>No temperature data available.</p>";
    }
}
?>
          
          
          
    </div>
</div>

<!---progress bar code ---->


 <?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "lumbira_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT totalincome, lossMade FROM salesreport";
$result = $conn->query($sql);

// Initialize variables
$totalIncome = 0;
$totalLoss = 0;

// Check if any rows were returned
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Sum up total income and total loss
        $totalIncome += intval($row['totalincome']);
        $totalLoss += intval($row['lossMade']);
    }
} else {
    echo "0 results";
}

// Close the connection
$conn->close();

// Calculate total
$total = $totalIncome + $totalLoss;

// Calculate percentages
$profitPercentage = ($totalIncome / $total) * 100;
$lossPercentage = ($totalLoss / $total) * 100;
?>
<div class="flex2">
<div class="item6">
    <div class="circular-progress profit-progress">
        <span class="progress-value"><?php echo round($profitPercentage); ?>%</span>
    </div>
    <span class="text">Profit Made</span>
</div>

<br>
<div class="item7">
    <div class="circular-progress loss-progress">
        <span class="progress-value"><?php echo round($lossPercentage); ?>%</span>
    </div>
    <span class="text">Loss Made</span>
</div>

</div>
</div>
<!-- JavaScript -->



<script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
<script>


    let profitCircularProgress = document.querySelector(".profit-progress"),
        lossCircularProgress = document.querySelector(".loss-progress");

    let profitProgressValue = profitCircularProgress.querySelector(".progress-value"),
        lossProgressValue = lossCircularProgress.querySelector(".progress-value");

    let profitProgressStartValue = 0,
        lossProgressStartValue = 0,
        profitProgressEndValue = <?php echo round($profitPercentage); ?>,
        lossProgressEndValue = <?php echo round($lossPercentage); ?>,
        speed = 100;

    let profitProgress = setInterval(() => {
        profitProgressStartValue++;
        profitProgressValue.textContent = `${profitProgressStartValue}%`;
        profitCircularProgress.style.background = `conic-gradient(#4CAF58 ${profitProgressStartValue * 3.6}deg, #ededed 0deg)`;

        if (profitProgressStartValue === profitProgressEndValue) {
            clearInterval(profitProgress);
        }
    }, speed);

    let lossProgress = setInterval(() => {
        lossProgressStartValue++;
        lossProgressValue.textContent = `${lossProgressStartValue}%`;
        lossCircularProgress.style.background = `conic-gradient(#FF5733 ${lossProgressStartValue * 3.6}deg, #ededed 0deg)`;

        if (lossProgressStartValue === lossProgressEndValue) {
            clearInterval(lossProgress);
        }
    }, speed);
</script>



</body>
</html>
