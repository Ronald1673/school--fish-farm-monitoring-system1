<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <link rel="shortcut icon" type="x-icon" href="../image/icon.png">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Administrator</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/st.css">
   <link rel="stylesheet" href="../css/loader.css">



</head>
<body>
          <!--loader-->
<div class="loader"></div>

<div class="container">

   <div class="content">
      <h3>Hello, <span>Admin</span></h3>
      <h1>welcome <span><?php echo $_SESSION['user_name'] ?></span></h1>
      <a href="index.php" class="btn">View Dashboard</a>
      <a href="logout.php" class="btn">Logout</a>
   </div>

</div>

<script>
        window.addEventListener("load", () => {
  const loader = document.querySelector(".loader");

  loader.classList.add("loader--hidden");

  loader.addEventListener("transitionend", () => {
    document.body.removeChild(loader);
  });
});
</script>
</body>
</html>