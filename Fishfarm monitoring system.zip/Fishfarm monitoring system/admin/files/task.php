<?php
include 'config.php';

if (isset($_POST['submit'])){
    include 'config.php';
  
  
    $Fishname=mysqli_real_escape_string($conn,$_POST['Fishname']);
    $Color=$_POST['Color'];
    $Tankname=$_POST['Tankname'];
    $Origin=$_POST['Origin'];
    $Age=$_POST['Age'];
    $Feedtype=$_POST['Feedtype'];
    $NumberOfFish=$_POST['NumberOfFish'];
   
    $sql="INSERT INTO TypesOfFish (Fishname,Color,Tankname,Origin,Age,Feedtype,NumberOfFish)
    VALUES('$Fishname','$Color','$Tankname','$Origin','$Age','$Feedtype','$NumberOfFish')";
     mysqli_query($conn,$sql);
  
  }
  
  ?>
  <?php
  if(isset($_POST['submit'])) {
    echo "<script type='text/javascript'>alert('Data Entered succesifully');</script>";
  }
  ?>

?>
<?php
require_once "config.php";
$alerts = $conn->query("SELECT COUNT(Salesid) as total FROM Salesreport WHERE Salesid = 1 OR Salesid > 1");
$notification = $alerts->fetch_array();
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="../image/icon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task</title>
    <link rel="stylesheet" href="../css/cs.css">
    <link rel="stylesheet" href="../css/styel.css">
	 <link rel="stylesheet" href="../css/loader.css">
    <link rel="stylesheet" href="../css/font/css/all.css">
    <link rel="stylesheet" href="../css/task.css">
   
</head>
<body>
<div class="loader"></div>
    <div class="bar">

    </div>
    

    <div class="sidebar">
        <div class="sidebar-brand">
            <h2><span ></span>Lumbira fish farm</h2>
        </div>
        <br>
        <div class="im">
            <img class="im"src="../image/icon.png" alt="">
          </div>
    <br>
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="index.php" ><span class="fas fa-home fa-2x"></span><span>Home</span></a>
                </li>
                <li>
                    <a href="Notification.php" ><span class="fas fa-bell   fa-2x"></span><span>Notification</span><em><?php echo $notification['total'] ?></em></a>
                </li>
                <li>
                    <a href="Groups.php" ><span class="fa fa-users"></span><span>Groups</span></a>
                </li>
                <li>
                    <a href="Reports.php"><span><img src="../image/report.png_32.png" alt=""></span><span>Reports</span></a>
                </li>
              <li>
                  <a href="index2.php"><img src="../image/tank.png_32.png" alt=""><span>Tank Records</span></a>
                  </li>
                <li>
                    <a href="task.php" class="active"><span><img src="../image/task.png_32.png" alt=""></span><span>Records</span></a>
                </li>
    
                <li>
                    <a href="logout.php"><span class="fa-solid fa-right-from-bracket"></span><span>Logout</span></a>
                </li>
            </ul>
        </div>
    </div>
    <br>




        <h6 id="h6"> Enter Fish Details</h6>
    
      <form id="fishSalesForm" action="#" method="post">
      <label for="name">Tank Name:</label>
          <input type="text" id="name" name="Tankname" required>

          <label for="name">Fish Name:</label>
          <input type="text" id="name" name="Fishname" required>

          <label for="color" >Color:</label>
          <input type="text" id="color" name="Color"  >
          
          <label for="date">Origin:</label>
          <input type="text" id="origin" name="Origin" required>
  
          <label for="Age">Age:</label>
          <input id="Age" name="Age"  placeholder="number of Weeks" required>
  
          <label for="amountOfFish">Feed Type:</label>
          <input type="text" id="feedtype" name="Feedtype" required>
  
          <label for="fishSold">Number Of Fish:</label>
          <input type="number" id="number of fish" name="NumberOfFish" required>
  
          <button type="submit" name="submit">Submit</button>
      </form>
  
      
        
    
    <div class="ba">

        
    </div>
</body>
<script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
</html>


