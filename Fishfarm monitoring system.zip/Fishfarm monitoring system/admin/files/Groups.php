<?php
@include 'config.php';

?>
<?php
require_once "config.php";
$alerts = $conn->query("SELECT COUNT(Salesid) as total FROM Salesreport WHERE Salesid = 1 OR Salesid > 1");
$notification = $alerts->fetch_array();
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="../image/icon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers</title>
    <link rel="stylesheet" href="../css/cs.css">
    <link rel="stylesheet" href="../css/styel.css">
    <link rel="stylesheet" href="../css/font/css/all.css">
	<link rel="stylesheet" href="../css/loader">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .sidebar-menu ul li a {
    text-decoration: none;
    color:white;
}

    </style>
</head>
<body>
 <div class="loader"></div>
    <div class="bar">
    
        <form id="search">
            <input  id="search" type="text">
            <input id="se" type="submit"
             value="Search">
            </form>
            <style>
                input[type="submit"]{
                    opacity: 0;
                    transition: 1.3s;
                }
                input:not(:placeholder-shown)+
                input[type="submit"]{
                    opacity:9;
                }
            
            </style>

    </div>
    

    <div class="sidebar">
        <div class="sidebar-brand">
           
        </div>
        <br>
        <div class="im">
            <img class="im"src="../image/icon.png" alt="">
          </div>
    <br>
    <br>
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="index.php" ><span class="fas fa-home fa-2x"></span><span>Home</span></a>
                </li>
                <li>
                    <a href="Notification.php" ><span class="fas fa-bell   fa-2x"></span><span>Notification</span><em><?php echo $notification['total'] ?></em></a>
                </li>
                <li>
                    <a href="Groups.php" class="active"><span class="fa fa-users"></span><span>Groups</span></a>
                </li>
                <li>
                    <a href="Reports.php"><span><img src="../image/report.png_32.png" alt=""></span><span>Reports</span></a>
                </li>
                <li>
                  <a href="index2.php"><img src="../image/tank.png_32.png" alt=""><span>Tank Records</span></a>
                  </li>
                <li>
                    <a href="task.php"><span><img src="../image/task.png_32.png" alt=""></span><span>Records</span></a>
                </li>
    
                <li>
                    <a href="logout.php"><span class="fa-solid fa-right-from-bracket"></span><span>Logout</span></a>
                </li>
            </ul>
        </div>
    </div>
    <br>
    <h3 id="B">Division of Groups and Tank Assignment</h3>
<div class="flexed">

<div class="itemA">
<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "lumbira_db";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Select members
        $sql = "SELECT * FROM members";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $members = $result->fetch_all(MYSQLI_ASSOC);

            // Select all fish tanks
            $sql = "SELECT Tankname FROM typesoffish";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $fishTanks = $result->fetch_all(MYSQLI_ASSOC);
                $numTanks = count($fishTanks);

                // Divide members into groups of 4 and assign a fish tank to each group sequentially
                $groupedMembers = array_chunk($members, 4);

                // Display members and their assigned fish tank in each group in a Bootstrap table
                foreach ($groupedMembers as $key => $group) {
                    echo "<h3>Group " . ($key + 1) . "</h3>";
                    echo '<table class="table table-striped">';
                    echo '<thead><tr><th>Name</th><th>Fish Tank</th></tr></thead>';
                    echo '<tbody>';
                    $tankIndex = $key % $numTanks; // Ensure tank assignment wraps around if there are more groups than tanks
                    $tankName = $fishTanks[$tankIndex]['Tankname'];
                    foreach ($group as $member) {
                        echo '<tr><td>' . $member['name'] . '</td><td>' . $tankName . '</td></tr>';
                    }
                    echo '</tbody>';
                    echo '</table>';
                }
            } else {
                echo "No fish tanks available";
            }
        } else {
            echo "0 results";
        }
        ?>
    </div>
    
</div>
<br>


</div>


    
    <div class="ba"></div>
</body>
<script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
</html>


