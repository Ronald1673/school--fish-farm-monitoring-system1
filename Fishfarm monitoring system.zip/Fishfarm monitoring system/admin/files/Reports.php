<?php
@include 'config.php';

?>
<?php
require_once "config.php";
$alerts = $conn->query("SELECT COUNT(Salesid) as total FROM Salesreport WHERE Salesid = 1 OR Salesid > 1");
$notification = $alerts->fetch_array();
?> 

<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lumbira_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the database, grouping by month and summing totalIncome
$sql = "SELECT MONTH(date) AS month, YEAR(date) AS year, SUM(totalIncome) AS totalIncome FROM salesreport GROUP BY YEAR(date), MONTH(date)";
$result = $conn->query($sql);

$dataPoints = array();

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Fetch each row and add to dataPoints array
    while($row = $result->fetch_assoc()) {
        // Creating a date string in the format "YYYY-MM" for the x-value
        $date_string = $row["year"] . "-" . sprintf("%02d", $row["month"]);
        $dataPoint = array(
            "x" => strtotime($date_string) * 1000, // Convert date to Unix timestamp in milliseconds
            "y" => $row["totalIncome"]
        );
        array_push($dataPoints, $dataPoint);
    }
} else {
    echo "0 results";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="../image/icon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <link rel="stylesheet" href="../css/cs.css">
    <link rel="stylesheet" href="../css/styel.css">
	 <link rel="stylesheet" href="../css/loader.css">
    <link rel="stylesheet" href="../css/font/css/all.css">
   

    <script src="canvasjs.min.js"></script>
    <script src="../css/chart.umd.js"></script>
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: ""
	},
	axisX: {
		valueFormatString: "MMM DD", // Format to display both month and date
        interval: 1, // Display every label
        intervalType: "month" // Display labels by month
	},
	axisY: {
		title: "Total Income (Kwacha)",
		includeZero: true,
	},
	data: [{
		type: "splineArea",
		color: "#4CAF58",
		xValueType: "dateTime",
		xValueFormatString: "MMM DD", // Format to display both month and date
		yValueFormatString: "K#,##0.## Kwacha",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>,
        markerSize:15, // Set marker size
        markerColor: "#4CAF58" // Set marker color to red
	}]
});
 
chart.render();
 
}
</script>


</head>
<body>
    <div class="loader"></div>
    <div class="bar">
    
        <form id="search">
            <input  id="search" type="text">
            <input id="se" type="submit"
             value="Search">
            </form>
            <style>
                input[type="submit"]{
                    opacity: 0;
                    transition: 1.3s;
                }
                input:not(:placeholder-shown)+
                input[type="submit"]{
                    opacity:9;
                }
            
            </style>

        </div>
    </div>
    

    <div class="sidebar">
        <div class="sidebar-brand">
            <h2><span ></span>Welcome ADMIN</h2>
        </div>
        <br>
        <div class="im">
            <img class="im"src="../image/icon.png" alt="">
          </div>
    <br>
    <br>
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="index.php" ><span class="fas fa-home fa-2x"></span><span>Home</span></a>
                </li>
                <li>
                    <a href="Notification.php" ><span class="fas fa-bell   fa-2x"></span><span>Notification</span><em><?php echo $notification['total'] ?></em></a>
                </li>
                <li>
                    <a href="Groups.php" ><span class="fa fa-users"></span><span>Groups</span></a>
                </li>
                <li>
                    <a href="Reports.php"  class="active"><span><img src="../image/report.png_32.png" alt=""></span><span>Reports</span></a>
                </li>
				
				<li>
                  <a href="index2.php"><img src="../image/tank.png_32.png" alt=""><span>Tank Records</span></a>
                  </li>
				
                <li>
                    <a href="task.php"><span><img src="../image/task.png_32.png" alt=""></span><span>Records</span></a>
                </li>
    
                <li>
                    <a href="logout.php"><span class="fa-solid fa-right-from-bracket"></span><span>Logout</span></a>
                </li>
            </ul>
        </div>
    </div>
    <br>


    <h3 id="B">System Reports</h3>
    <div class="flexR">
        <div class="itemR">
<div class="bar"><h3 class="B" >Total Monthly sales Report</h3></div>
        <div id="chartContainer" style="height: 400px; width: 100%;"></div>
    
        </div>

        <div class="itemR2">

 <!---------Fish tank bar grapH-------->
            
<div class="bar"><h3 class="B" >Temperature & Water level Records</h3></div>
<canvas id="fishTankChart" width="fit-content" height="220"></canvas>

<?php
        // Include the table page
        include 'b1.php';
        ?>


        </div>
    
    </div>
    <br>
    <div class="bottom">
<div class="bottom1">
<div class="bar"><h3 class="B" ></h3></div>

<?php
        // Include the table page
        include 'b2.php';
        ?>
</div>
<br>
<div class="bottom2">
<div class="bar"><h3 class="B" >Fish Tank Data</h3></div>
<br>
       <?php
        // Include the table page
        include 'new.php';
        ?>
<br>
<?php
        // Include the table page
        include 'pdf.php';
        ?>


</div>
    </div>

    <div class="bottomm">
    <div class="bottom3">
<div class="bar"><h3 class="B" >Lumbira Fish Farm</h3></div>

<button type="button">
    <a href="index2.php" id="goToPageButton">Go to Another Page</a>
</button>

</div>
    </div>
</body>
<script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
</html>


