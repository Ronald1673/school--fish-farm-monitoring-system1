<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "lumbira_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query database to retrieve data from typesoffish where Tankname is 'Tank 1'
$sql = "SELECT Tankname, Fishname, Age, Feedtype, NumberOfFish FROM typesoffish WHERE Tankname = 'Tank 1'";
$result = $conn->query($sql);

// Check if record exists
if ($result->num_rows > 0) {
    // Fetch the data
    while ($row = $result->fetch_assoc()) {
        // Concatenate all values on a single line
        echo "Tankname: " . $row["Tankname"] . ",....  Fish Name: " . $row["Fishname"] . ",....   Age (Weeks old): " . $row["Age"] . ",....   Feed type: " . $row["Feedtype"] . ",....  Number Of Fish: " . $row["NumberOfFish"];
    }
} else {
    echo "No record found for Tankname: 'Tank 1'";
}

// Close database connection
$conn->close();
?>

