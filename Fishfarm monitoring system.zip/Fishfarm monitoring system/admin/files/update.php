<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Fish</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      padding-top: 50px;
    }
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="#">Fish Database</a>
  </nav>

  <?php
  // Establish database connection
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lumbira_db";

  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  // Check if the fish ID is provided
  if(isset($_GET['id'])) {
      $Fishid = $_GET['id'];
      
      // Fetch the fish data based on the provided ID
      $sql = "SELECT * FROM typesoffish WHERE Fishid = $Fishid";
      $result = $conn->query($sql);
      
      if ($result->num_rows > 0) {
          $row = $result->fetch_assoc();
          // Display the form to update fish data
          ?>
          <div class="container mt-5">
              <form action="update_process.php" method="POST">
                  <input type="hidden" name="Fishid" value="<?php echo $row['Fishid']; ?>">
                  <div class="form-group">
                      <label for="tank_name">Tank Name:</label>
                      <input type="text" class="form-control" id="tank_name" name="Tankname" value="<?php echo $row['Tankname']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="fish_name">Fish Name:</label>
                      <input type="text" class="form-control" id="fish_name" name="Fishname" value="<?php echo $row['Fishname']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="color">Color:</label>
                      <input type="text" class="form-control" id="color" name="Color" value="<?php echo $row['Color']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="origin">Origin:</label>
                      <input type="text" class="form-control" id="Origin" name="Origin" value="<?php echo $row['Origin']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="age">Age:</label>
                      <input type="number" class="form-control" id="age" name="Age" value="<?php echo $row['Age']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="feed_type">Feed Type:</label>
                      <input type="text" class="form-control" id="feed_type" name="Feedtype" value="<?php echo $row['Feedtype']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="number_of_fish">Number of Fish:</label>
                      <input type="number" class="form-control" id="number_of_Fish" name="NumberOfFish" value="<?php echo $row['NumberOfFish']; ?>">
                  </div>
                  <button type="submit" class="btn btn-primary">Update</button>
              </form>
          </div>
          <?php
      } else {
          echo "Fish not found.";
      }
  } else {
      echo "Fish ID not provided.";
  }

  $conn->close();
  ?>

  <!-- Bootstrap JS and jQuery -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

