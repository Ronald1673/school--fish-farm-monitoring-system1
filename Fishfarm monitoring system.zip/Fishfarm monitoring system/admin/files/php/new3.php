<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/PHPMailer/src/Exception.php';
require 'vendor/PHPMailer/src/PHPMailer.php';
require 'vendor/PHPMailer/src/SMTP.php';

session_start();

// Function to send email
function sendEmail($subject, $message, $email, $temperature)
{
    $mail = new PHPMailer(true);                            
    try {
        // Server settings
        $mail->isSMTP();                                     
        $mail->Host = 'smtp.gmail.com';                      
        $mail->SMTPAuth = true;                             
        $mail->Username = 'lumbirafishfarm@gmail.com';     
        $mail->Password = 'sapv kkck umfn zgyr';             
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );                         
        $mail->SMTPSecure = 'ssl';                           
        $mail->Port = 465;                                   

        // Send Email
        $mail->setFrom('lumbirafishfarm@gmail.com' );
        
        // Recipients
        $mail->addAddress($email);              
        $mail->addReplyTo('lumbirafishfarm@gmail.com');
        
        // Content
        $mail->isHTML(true);                                  
        $mail->Subject = $subject;
        $mail->Body    = $message . "<br><br>Actual temperature: " . $temperature . "°C";

        $mail->send();
        $_SESSION['result'] = 'Message has been sent';
        $_SESSION['status'] = 'ok';
    } catch (Exception $e) {
        $_SESSION['result'] = 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo;
        $_SESSION['status'] = 'error';
    }
}

// Function to fetch recipient email addresses from the database
function getRecipientEmails()
{
    // Establish database connection
    $servername = "localhost"; // Change this if your database server is different
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "lumbira_db"; // Change this to your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to fetch email addresses from admin table
    $sql = "SELECT email FROM admin";
    $result = $conn->query($sql);

    $emails = array();

    if ($result->num_rows > 0) {
        // Fetch email addresses
        while ($row = $result->fetch_assoc()) {
            $emails[] = $row["email"];
        }
    }

    $conn->close();

    return $emails;
}

// Fetch temperature data from Arduino
$temperatureData = @file_get_contents('http://192.168.137.22/getTemperature');

if ($temperatureData === FALSE) {
    // Handle error case for temperature
    echo "<p>Error fetching temperature.</p>";
} else {
    // Decode JSON data for temperature
    $temperatureArray = json_decode($temperatureData, true);

    if (isset($temperatureArray['temperature'])) {
        // Extract temperature value
        $waterTemperature = $temperatureArray['temperature'];
        echo '<label for="watertemperature">Water Temperature:</label>';
        echo '<input class="myInput" type="text" id="watertemperature" name="waterTemperature" value="' . $waterTemperature . ' &deg;C" readonly>';
        
        // Get recipient email addresses from the database
        $recipientEmails = getRecipientEmails();
        
        if (!empty($recipientEmails)) {
            foreach ($recipientEmails as $recipientEmail) {
                // Check temperature range and set circle class accordingly
                if ($waterTemperature < 20.0) {
                    echo '<div id="blink-circle" class="blink-blue"></div>';
                    // Send email notification for low temperature
                    sendEmail("Low Temperature Warning", "The water temperature is below 20 degrees Celsius.", $recipientEmail, $waterTemperature);
                } elseif ($waterTemperature > 30.0) {
                    echo '<div id="blink-circle" class="blink-red"></div>';
                    // Send email notification for high temperature
                    sendEmail("High Temperature Warning", "The water temperature is above 30 degrees Celsius.", $recipientEmail, $waterTemperature);
                } else {
                    echo '<div id="blink-circle" class="green"></div>';
                }
            }
        } else {
            echo "<p>No recipient email addresses found.</p>";
        }
    } else {
        // Handle case where temperature is not available
        echo "<p>No temperature data available.</p>";
    }
}
?>

<script>
// Refresh the page after 1 minute
setTimeout(function() {
    location.reload();
}, 60000); // 60000 milliseconds = 1 minute
</script>
