<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fish Database</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      padding-top: 50px;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <!-- Back button -->
  <a href="index.php" class="btn btn-secondary mb-3">Home</a>
  <a href="Reports.php" class="btn btn-secondary mb-3">Reports</a>

  <div class="table-responsive">
    <?php
    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lumbira_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Fetch data from the database
    $sql = "SELECT * FROM typesoffish";
    $result = $conn->query($sql);

    // Display data in a table
    if ($result->num_rows > 0) {
      echo "<table class='table table-bordered table-dark'>
          <thead>
            <tr>
              <th>Fish ID</th>
              <th>Tank Name</th>
              <th>Fish Name</th>
              <th>Color</th>
              <th>Origin</th>
              <th>Age</th>
              <th>Feed Type</th>
              <th>Number of Fish</th>
              <th>Update</th>
            </tr>
          </thead>
          <tbody>";
      while($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>".$row["Fishid"]."</td>
            <td>".$row["Tankname"]."</td>
            <td>".$row["Fishname"]."</td>
            <td>".$row["Color"]."</td>
            <td>".$row["Origin"]."</td>
            <td>".$row["Age"]."</td>
            <td>".$row["Feedtype"]."</td>
            <td>".$row["NumberOfFish"]."</td>
            <td><button class='btn btn-primary' style='background-color: #77b0f5;' onclick='updateFish(".$row["Fishid"].")'>Update</button></td>
          </tr>";
      }
      echo "</tbody></table>";
    } else {
      echo "0 results";
    }

    $conn->close();
    ?>
  </div>
</div>

<!-- JavaScript -->
<script>
  function updateFish(fish_id) {
    // Redirect to update page with fish ID as parameter
    window.location.href = "update.php?id=" + fish_id;
  }
</script>

<!-- Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

