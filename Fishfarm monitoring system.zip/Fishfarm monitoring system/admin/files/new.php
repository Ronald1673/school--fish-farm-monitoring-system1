<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fish Tank Report</title>
    <style>
        #bottom2 {
            flex: 2 2 100px;
            background-color: whitesmoke;
            height: 500px;
            font-size:17px;
            margin: 10px;
            border-radius: 5px;
            width:600rem;
            box-shadow: 5px 10px 25px #77b0f5;
            overflow: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #333;
            color: white;
        }
        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        #hh2{
            font-size: 17px;
            color:black;
        }
    </style>
</head>
<body>
   
    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $dbname = "lumbira_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query
    $sql = "SELECT Tankname, Fishname, Age FROM typesoffish";

    // Execute query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Output report header
        echo "<table>";
        echo "<thead>";
        echo "<tr><th>Tankname</th><th>Fishname</th><th>Age (weeks)</th><th>Remaining Weeks to Mature</th><th>Maturity Date</th></tr>";
        echo "</thead>";
        echo "<tbody>";
        
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            $current_age = $row["Age"];
            $maturity_age = 10; // Maturity age in weeks
            $remaining_weeks = $maturity_age - $current_age;
            
            // Calculate the date when the remaining weeks will be reached
            $current_date = date_create();
            $future_date = date_add($current_date, date_interval_create_from_date_string($remaining_weeks . " weeks"));
            $maturity_date = date_format($future_date, 'Y-m-d');
            
            // Output row data
            echo "<tr>";
            echo "<td>" . $row["Tankname"] . "</td>";
            echo "<td>" . $row["Fishname"] . "</td>";
            echo "<td>" . $row["Age"] . "</td>";
            echo "<td>" . $remaining_weeks . "</td>";
            echo "<td>" . $maturity_date . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "0 results";
    }

    // Close connection
    $conn->close();
    ?>
	
	<br>

    <?php
    // Database credentials
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "lumbira_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to get the highest value in the Temperature column along with the corresponding date and time
    $query_temperature = "SELECT Date, Time, MAX(Temperature) AS max_temperature FROM fishtank";

    // Execute the temperature query
    $result_temperature = $conn->query($query_temperature);

    // Check if the temperature query was successful
    if ($result_temperature === false) {
        die("Error executing temperature query: " . $conn->error);
    }

    // Fetch the temperature result
    $row_temperature = $result_temperature->fetch_assoc();
    $highest_temperature = $row_temperature['max_temperature'];
    $date_recorded_temperature = $row_temperature['Date'];
    $time_recorded_temperature = $row_temperature['Time'];

    // Query to get the highest value in the Waterlevel column along with the corresponding date and time
    $query_waterlevel = "SELECT Date, Time, MAX(Waterlevel) AS max_waterlevel FROM fishtank";

    // Execute the waterlevel query
    $result_waterlevel = $conn->query($query_waterlevel);

    // Check if the waterlevel query was successful
    if ($result_waterlevel === false) {
        die("Error executing waterlevel query: " . $conn->error);
    }

    // Fetch the waterlevel result
    $row_waterlevel = $result_waterlevel->fetch_assoc();
    $highest_waterlevel = $row_waterlevel['max_waterlevel'];
    $date_recorded_waterlevel = $row_waterlevel['Date'];
    $time_recorded_waterlevel = $row_waterlevel['Time'];

    // Close the database connection
    $conn->close();
    ?>

    <h2 id="hh2">Highest Temperature and Water Level</h2>
    <table>
        <thead>
            <tr>
                <th>Recorded Date</th>
                <th>Recorded Time</th>
                <th>Highest Temperature (°C)</th>
                <th>Recorded Date</th>
                <th>Recorded Time</th>
                <th>Highest Water Level (%)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $date_recorded_temperature; ?></td>
                <td><?php echo $time_recorded_temperature; ?></td>
                <td><?php echo $highest_temperature; ?></td>
                <td><?php echo $date_recorded_waterlevel; ?></td>
                <td><?php echo $time_recorded_waterlevel; ?></td>
                <td><?php echo $highest_waterlevel; ?></td>
            </tr>
        </tbody>
    </table>

    <br>

    <h2>Recommended Settings for Fish Tank</h2>
    <table>
        <thead>
            <tr>
                <th>Setting</th>
                <th>Recommended Value</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Temperature</td>
                <td>25°C</td>
            </tr>
            <tr>
                <td>Water Level</td>
                <td>65%</td>
            </tr>
        </tbody>
    </table>

    
</body>
</html>

