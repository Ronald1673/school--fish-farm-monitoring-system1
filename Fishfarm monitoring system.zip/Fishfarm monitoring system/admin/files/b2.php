<?php
// MySQL database connection details
$servername = "localhost";
$username = "root"; // replace with your username
$password = ""; // replace with your password
$database = "lumbira_db"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve total income from salesreport table
$sql = "SELECT SUM(totalincome) AS total_income FROM salesreport";
$result = $conn->query($sql);

$total_income = 0;

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $total_income = $row["total_income"];
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header #h11 {
            color: #333;
        }

        .report {
            margin-bottom: 20px;
        }

        .report h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .report p {
            color: #666;
            display: none; /* Hide total income by default */
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            color: #888;
        }

        .footer p {
            font-size: 14px;
        }

        /* Button style */
        .button {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #2E3239 ;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color:#4CAF58;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 id="h11">Total Sales and Expense Report</h1>
        </div>
        <div class="report">
            <h2>Total income made from sales of the year:</h2>
            <p id="totalIncome">K<?php echo number_format($total_income, 2); ?></p>
        </div>
        <button id="viewAmount" class="button" onclick="toggleAmount()">View Amount</button>
        
    </div>

    <script>
        function toggleAmount() {
            var totalIncome = document.getElementById("totalIncome");
            if (totalIncome.style.display === "none") {
                totalIncome.style.display = "block";
                document.getElementById("viewAmount").innerText = "Hide Amount";
            } else {
                totalIncome.style.display = "none";
                document.getElementById("viewAmount").innerText = "View Amount";
            }
        }
    </script>
</body>
</html>
