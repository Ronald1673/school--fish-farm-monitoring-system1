<?php
require_once('TCPDF/tcpdf.php');

// Initialize TCPDF
$pdf = new TCPDF();
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Lumbira Fish Farm');
$pdf->SetTitle('Fish Tank Report');
$pdf->SetSubject('Fish Tank Report');
$pdf->SetKeywords('fish, tank, report, pdf');
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 12);

// Header for Recommended Settings for Fish Tank
$pdf->SetFont('helvetica', 'B', 15);
$pdf->Cell(0, 0, '', 0, false, 'C', 0, '', 0, false, 'M', 'M');
$pdf->Ln(5); // Adding margin
$pdf->Cell(0, 0, 'Lumbira Fish Farm', 0, false, 'C', 0, '', 0, false, 'M', 'M');
$pdf->Ln(15); // Adjust spacing between header and line

// Recommended Settings table
$html = '<h2>Recommended Settings for Fish Tank</h2>';
$html .= '<table>';
$html .= '<thead>';
$html .= '<tr>';
$html .= '<th>Setting</th>';
$html .= '<th>Recommended Value</th>';
$html .= '</tr>';
$html .= '</thead>';
$html .= '<tbody>';
$html .= '<tr>';
$html .= '<td>Temperature</td>';
$html .= '<td>25°C</td>';
$html .= '</tr>';
$html .= '<tr>';
$html .= '<td>Water Level</td>';
$html .= '<td>65%</td>';
$html .= '</tr>';
$html .= '</tbody>';
$html .= '</table>';

$pdf->writeHTML($html, true, false, true, false, '');

// Connect to MySQL database (assuming localhost with username 'root' and no password)
$mysqli = new mysqli("localhost", "root", "", "lumbira_db"); // Changed database name to lumbira_db

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Header for Highest Temperature and Water Level
$pdf->Ln(20); // Add spacing between tables
$pdf->SetFont('helvetica', 'B', 15);
$pdf->Cell(0, 0, '', 0, false, 'C', 0, '', 0, false, 'M', 'M');
$pdf->Ln(5); // Adding margin
$pdf->Cell(0, 0, 'Highest Temperature and Water Levels Recorded', 0, false, 'C', 0, '', 0, false, 'M', 'M');
$pdf->Ln(15); // Adjust spacing between header and line

// Content from database - Highest Temperature and Water Level
$pdf->SetFont('helvetica', '', 10);

// Define table columns for Highest Temperature and Water Level
$header_highest_temp_water_level = array('Highest Temperature', 'Date', 'Time', 'Highest Water Level', 'Date', 'Time');

// Set table header styling for Highest Temperature and Water Level
$pdf->SetFillColor(46, 50, 57); // Background color
$pdf->SetTextColor(255, 255, 255); // Text color
$pdf->SetDrawColor(46, 50, 57); // Border color
$pdf->SetFont('helvetica', 'B', 10);

// Calculate cell width based on available page width and number of columns
$cellWidth = $pdf->getPageWidth() / count($header_highest_temp_water_level);

// Add table header for Highest Temperature and Water Level
foreach($header_highest_temp_water_level as $col) {
    $pdf->Cell($cellWidth, 10, $col, 1, 0, 'C', 1); // With border, centered, and fill
}
$pdf->Ln();

// Query to get the highest value in the Temperature column along with the corresponding date and time
$query_temperature = "SELECT Date, Time, MAX(Temperature) AS max_temperature FROM fishtank";

// Execute the temperature query
$result_temperature = $mysqli->query($query_temperature);

// Fetch the temperature result
$row_temperature = $result_temperature->fetch_assoc();
$highest_temperature = $row_temperature['max_temperature'];
$date_recorded_temperature = $row_temperature['Date'];
$time_recorded_temperature = $row_temperature['Time'];

// Query to get the highest value in the Waterlevel column along with the corresponding date and time
$query_waterlevel = "SELECT Date, Time, MAX(Waterlevel) AS max_waterlevel FROM fishtank";

// Execute the waterlevel query
$result_waterlevel = $mysqli->query($query_waterlevel);

// Fetch the waterlevel result
$row_waterlevel = $result_waterlevel->fetch_assoc();
$highest_waterlevel = $row_waterlevel['max_waterlevel'];
$date_recorded_waterlevel = $row_waterlevel['Date'];
$time_recorded_waterlevel = $row_waterlevel['Time'];

// Set table data styling for Highest Temperature and Water Level
$pdf->SetFillColor(255); // Background color
$pdf->SetTextColor(0); // Text color
$pdf->SetDrawColor(46, 50, 57); // Border color
$pdf->SetFont('helvetica', '', 10);

// Add data for Highest Temperature and Water Level
$pdf->Cell($cellWidth, 10, $highest_temperature . ' °C', 1, 0, 'C', 0);
$pdf->Cell($cellWidth, 10, $date_recorded_temperature, 1, 0, 'C', 0);
$pdf->Cell($cellWidth, 10, $time_recorded_temperature, 1, 0, 'C', 0);
$pdf->Cell($cellWidth, 10, $highest_waterlevel . ' %', 1, 0, 'C', 0);
$pdf->Cell($cellWidth, 10, $date_recorded_waterlevel, 1, 0, 'C', 0);
$pdf->Cell($cellWidth, 10, $time_recorded_waterlevel, 1, 0, 'C', 0);

// Database connection parameters
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "lumbira_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query
$sql = "SELECT Tankname, Fishname, Age FROM typesoffish";

// Execute query
$result = $conn->query($sql);

// Check if there are any results
if ($result->num_rows > 0) {
    // Output report header
    $pdf->Ln(20); // Add spacing between tables
    $pdf->SetFont('helvetica', 'B', 15);
    $pdf->Cell(0, 0, '', 0, false, 'C', 0, '', 0, false, 'M', 'M');
    $pdf->Ln(5); // Adding margin
    $pdf->Cell(0, 0, 'Types of Fish and Their Maturity', 0, false, 'C', 0, '', 0, false, 'M', 'M');
    $pdf->Ln(15); // Adjust spacing between header and line

    // Output table header
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->SetFillColor(46, 50, 57);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetDrawColor(46, 50, 57);
    $pdf->Cell(40, 10, 'Tankname', 1, 0, 'C', 1);
    $pdf->Cell(40, 10, 'Fishname', 1, 0, 'C', 1);
    $pdf->Cell(30, 10, 'Age (weeks)', 1, 0, 'C', 1);
    $pdf->Cell(40, 10, 'Remaining Weeks to Mature', 1, 0, 'C', 1);
    $pdf->Cell(40, 10, 'Maturity Date', 1, 1, 'C', 1); // New line after this cell

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $current_age = $row["Age"];
        $maturity_age = 10; // Maturity age in weeks
        $remaining_weeks = $maturity_age - $current_age;

        // Calculate the date when the remaining weeks will be reached
        $current_date = date_create();
        $future_date = date_add($current_date, date_interval_create_from_date_string($remaining_weeks . " weeks"));
        $maturity_date = date_format($future_date, 'Y-m-d');

        // Output row data
        $pdf->SetFont('helvetica', '', 10);
        $pdf->SetFillColor(255);
        $pdf->SetTextColor(0);
        $pdf->SetDrawColor(46, 50, 57);
        $pdf->Cell(40, 10, $row["Tankname"], 1, 0, 'C', 0);
        $pdf->Cell(40, 10, $row["Fishname"], 1, 0, 'C', 0);
        $pdf->Cell(30, 10, $row["Age"], 1, 0, 'C', 0);
        $pdf->Cell(40, 10, $remaining_weeks, 1, 0, 'C', 0);
        $pdf->Cell(40, 10, $maturity_date, 1, 1, 'C', 0); // New line after this cell
    }
} else {
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'No results found', 0, 1);
}

// Close database connection
$conn->close();

// Output PDF
$pdf->Output('fish_tank_report.pdf', 'D');
?>
