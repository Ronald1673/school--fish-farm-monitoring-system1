<?php
include('config.php');
$Salesid = $_GET['Salesid'];
$result = mysqli_query($conn, "DELETE FROM Salesreport where Salesid='$Salesid'");
header('location:Notification.php');
?>