<?php
include 'config.php';

session_start();

$error = array(); // Initialize an empty array for errors

if(isset($_POST['submit'])){
   // Ensure you have a database connection
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']); 
   
   $select = "SELECT * FROM Admin WHERE email = '$email' && password = '$pass' ";
   
   $result = mysqli_query($conn, $select);
   
   if(mysqli_num_rows($result) > 0){
      $row = mysqli_fetch_array($result);

      $_SESSION['user_name'] = $row['name'];

      if($row['user_type'] == 'Administrator'){
         header('location:files/user.php');
         exit();
      } 
   } else {
      $error[] = 'Incorrect email or password!!!';
   }

   // Close the database connection
   mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="x-icon" href="image/icon.png">
    <title>Login</title>
    <link rel="stylesheet" href="css/style22.css">
    <link rel="stylesheet" href="css/font/css/all.css">
    <style>
      .container2{
        padding: 0px;
        max-width: 440px;
        padding: 0 20px;
        margin: 10px auto;
      }
 
.logo2 img {
  width: 100px; 
  height: auto;
  border-radius:50%;
}
.container2 {
  text-align: center;
}

.logo2 {
  display: inline-block;
}

    </style>
  </head>
  <body>
    <div class="container2">
      <div class="logo2">
        <img src="image/Icon.png" alt="Logo">
        <h2>Lumbira Fish Farm</h2> <!-- Modified the image source -->
      </div>

      <div class="wrapper">
        <div class="title"><span>Login</span></div>

        <form method="post" action="#"> <!-- Added method and action attributes to the form -->
          <br>
          <?php
            if(isset($error)){
               foreach($error as $error){
                  echo '<span class="error-msg">'.$error.'</span>';
               };
            };
          ?>
          <br>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="email" name="email" placeholder="Email" required> <!-- Added name attribute to input fields -->
          </div>
          <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required> <!-- Added name attribute to input fields -->
          </div>
          
          <div class="row button">
            <input type="submit" name="submit" value="Login"> <!-- Added name attribute to the submit button -->
          </div>
          
          <div class="signup-link">Not a member? <a href="signup.php">Signup now</a></div>

          <div class="signup-link"><a href="index.html">Cancel</a></div>
        </form>
      </div>
    </div>
  </body>
</html>
