<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Lumbira_db";

// Create a connection to create the database
$conn = new mysqli($servername, $username, $password);

// Check connection for creating the database
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Creation of the database
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database has been created successfully<br>";
} else {
    echo "Error in creating database: " . $conn->error;
}
$conn->close();

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Creating admin table
$sql = "CREATE TABLE IF NOT EXISTS `Admin` (
    id INT(20) PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    name VARCHAR(225),
    email VARCHAR(225),
    password VARCHAR(225),
    user_type VARCHAR(20) 
)";

if ($conn->query($sql) === TRUE) {
    echo "Table Admin created/table successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}

// Insert initial admin data
$sql = "INSERT INTO `Admin` (`name`, `email`, `password`, `user_type`) VALUES
    ('ronald', 'mangisa@gmail.com', '123', 'Administrator')"; 

if ($conn->query($sql) === TRUE) {
    echo "Admin data successfully entered<br>";
} else {
    echo "Error: " . $conn->error;
}

// Creating members table
$sql = "CREATE TABLE IF NOT EXISTS `Members` (
    Membersid INT(20) PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    name VARCHAR(25),
    email VARCHAR(25),
    password VARCHAR(225),
    user_type VARCHAR(30),
    gender VARCHAR(10)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table Members created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}

// Insert initial member data
$sql = "INSERT INTO `Members` (`name`, `email`, `password`, `user_type`, `gender`) VALUES
    ('Ronald', 'mangisa@gmail.com', '123', 'Member', 'Male')"; 

if ($conn->query($sql) === TRUE) {
    echo "Members data successfully entered<br>";
} else {
    echo "Error: " . $conn->error;
}


// Creating Salesreport table
$sql = "CREATE TABLE IF NOT EXISTS `Salesreport` (
    Salesid INT(10) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    Membersid INT(10), 
    Membername VARCHAR(20),
    date Date,
    description Text(225),
    PriceOfFish VARCHAR(20),
    fishSold INT(20),
    FishLeft INT(20),
    totalIncome VARCHAR(20),
    lossMade VARCHAR(20),
    FOREIGN KEY (`Membersid`) REFERENCES `Members`(`Membersid`)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table Salesreport created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}


// Creating Types of fish table
$sql = "CREATE TABLE IF NOT EXISTS `TypesOfFish` (
    Fishid INT(10) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Tankname VARCHAR(10), 
    Fishname VARCHAR(20) ,
    Color VARCHAR(25),
    Origin VARCHAR(20),
    Age INT(11),
    Feedtype VARCHAR(25),
    NumberOfFish INT(10)
      
)";

if ($conn->query($sql) === TRUE) {
    echo "Table for Fish types created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}

// Creating Fishtank table
$sql = "CREATE TABLE IF NOT EXISTS `Fishtank` (
    Dataid INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    Waterlevel Varchar(10), 
    Temperature Varchar (20),
    Time TIME,
    Date  DATE  
)";

if ($conn->query($sql) === TRUE) {
    echo "Table for Fishtank created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}




// Creating Types of fish table
$sql = "CREATE TABLE IF NOT EXISTS `TypesOfFish` (
    Fishid INT(10) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Tankname VARCHAR(10), 
    Fishname VARCHAR(20) ,
    Color VARCHAR(25),
    Origin VARCHAR(20),
    Age INT(11),
    Feedtype VARCHAR(25),
    NumberOfFish INT(10)
      
)";

if ($conn->query($sql) === TRUE) {
    echo "Table for Expenses created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}

// Creating Fishtank table
$sql = "CREATE TABLE IF NOT EXISTS `Expenses` (
    Dataid INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    Feedname Varchar(10), 
    Number of bags INT (20),
    Date  DATE,
    Amount INT(225)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table for Expenses created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}






// Close the connection
$conn->close();

echo "<a href='index.html'><button class='btn btn-primary py-3 px-5 btn-pill'
    style='background-color: lightblue; width: 279px; height: 40px; color: white; font-size: 20px; cursor: pointer; border-radius: 25px;'>Proceed</button></a>";
?>
