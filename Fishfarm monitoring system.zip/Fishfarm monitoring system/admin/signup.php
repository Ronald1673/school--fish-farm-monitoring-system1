
<?php
// Initialize the error array
$errors = array();

if (isset($_POST['submit'])) {
    // Include the config.php file
    include 'config.php';

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = md5($_POST['password']);
    $cpass = md5($_POST['cpassword']);
    $user_type = $_POST['user_type'];

    // Validate the inputs
    if (empty($name)) {
        $errors[] = 'Name is required';
    }
    if (empty($email)) {
        $errors[] = 'Email is required';
    }
    
    if (empty($errors)) {
      $select = "SELECT * FROM Admin WHERE email = '$email'";
      $result = mysqli_query($conn, $select);
  
      if (mysqli_num_rows($result) > 0) {
          $errors[] = 'User already exists!';
      } else {
          if ($pass != $cpass) {
              $errors[] = 'Passwords do not match!';
          } else {
              $insert = "INSERT INTO Admin (name, email, password, user_type) VALUES ('$name','$email','$pass','$user_type')";
              if (mysqli_query($conn, $insert)) {
                  echo "<script type='text/javascript'>alert('Administrator registered sucessfully'); window.location = 'login.php';</script>";
                  exit();
              } else {
                  $errors[] = 'Error: ' . mysqli_error($conn);
              }
          }
      }
  }
}
?>  
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="x-icon" href="image/icon.png">
    <title>Registration</title>
    <link rel="stylesheet" href="css/style22.css">
    <link rel="stylesheet" href="css/font/css/all.css">
    <link rel="stylesheet" href="../css/style22.css">
</head>
<body>

<div class="contain">
    <div class="wrapper">
        <div class="title"><span>Registration</span></div>
        
        <h3>Administrator</h3>
        <form action="#" method="post">
            <?php
            if (!empty($errors)) { // Corrected variable name
                foreach ($errors as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                }
            }
            ?>

            <div class="row">
                <i class="fas fa-user"></i>
                <input type="text" name="name" placeholder="Name" required>
            </div>
            <div class="row">
                <i class="fas fa-envelope"></i>
                <input type="text" name="email" placeholder="Email" required>
            </div>

            <div class="row">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <div class="row">
                <i class="fas fa-lock"></i>
                <input type="password" name="cpassword" placeholder="Confirm Password" required>
            </div>

            <div class="row">
                <select name="user_type">
                    <option value="Administrator">Administrator</option>
                </select>
            </div>
            <br>
            <div class="row button">
                <input type="submit" name="submit"value="Register">
            </div>
            <div class="signup-link">Already a member? <a href="login.php">Login</a></div>

            <div class="signup-link"><a href="index.html">Cancel</a></div>
        </form>
    </div>
</div>
</body>
</html>