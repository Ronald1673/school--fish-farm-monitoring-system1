<?php

$conn = mysqli_connect('localhost','root','','Lumbira_db') or die("Database connection failed");


?>