<?php
include 'config.php';

session_start();

$error = array(); // Initialize an empty array for errors

if(isset($_POST['submit'])){
   // Ensure you have a database connection
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']); 
   
   $select = "SELECT * FROM Members WHERE email = '$email' && password = '$pass' ";
   
   $result = mysqli_query($conn, $select);
   
   if(mysqli_num_rows($result) > 0){
      $row = mysqli_fetch_array($result);

      $_SESSION['user_name'] = $row['name'];

      if($row['user_type'] == 'Member'){
         header('location:pages/index.php');
         exit();
      } elseif($row['user_type'] == 'Customer'){
         header('location:Customer/index.html');
         exit();
      }
   } else {
      $error[] = 'Incorrect email or password!!!';
   }

   // Close the database connection
   mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="x-icon" href="image/icon.png">
    <title>Login</title>
    <link rel="stylesheet" href="css/style22.css">
    <link rel="stylesheet" href="css/font/css/all.css">
    <link rel="stylesheet" href="css/loader.css">

  </head>
  <body>
  <div class="loader"></div>
    <div class="container">
      <div class="logo">
        <img src="image/Icon.png" alt="Logo">
        <h2>Lumbira Fish Farm</h2> <!-- Modified the image source -->
      </div>

      <div class="wrapper">
        <div class="title"><span>Login</span></div>

        <form method="post" action="#"> <!-- Added method and action attributes to the form -->
          <br>
          <?php
            if(isset($error)){
               foreach($error as $error){
                  echo '<span class="error-msg">'.$error.'</span>';
               };
            };
          ?>
          <br>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="email" name="email" placeholder="Email" required> <!-- Added name attribute to input fields -->
          </div>
          <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required> <!-- Added name attribute to input fields -->
          </div>
          
          <div class="row button">
            <input type="submit" name="submit" value="Login"> <!-- Added name attribute to the submit button -->
          </div>
          <div class="signup-link">Not a member? <a href="signup.php">Signup now</a></div>

          <div class="signup-link"><a href="index.html">Cancel</a></div>
        </form>
      </div>
    </div>
    <script>
    window.addEventListener("load", () => {
const loader = document.querySelector(".loader");

loader.classList.add("loader--hidden");

loader.addEventListener("transitionend", () => {
document.body.removeChild(loader);
});
});
</script>
</body>
</html>
